# culvers.com — recon report (2026-06-09)

> Сделан тем же подходом что arbys: curl_cffi+asocks-residential US fingerprint
> (homepage и сам сайт триггерят WAF на не-US datacenter-IP).
> WAF/чёрный список без US-IP даёт 403 from CloudFront/Check Point.

## Стек одной картинкой

```
              Visitor (US IP required)
                       │
        ┌──────────────┼─────────────┬─────────────────────┐
        ▼              ▼             ▼                     ▼
  www.culvers.com  welcome.        orderonline.       api.culvers.com
  (CloudFront +    culvers.com     culvers.com        (Azure FD +
   Check Point     (Azure FD →     (CloudFlare →      Azure APIM)
   AppSec WAF →    Azure AD B2C)   whitelabel.olo.com)
   Azure FD →                          │
   Next.js SSR)                        ▼
   Agility CMS              Olo whitelabel Next.js
                            (serve-next.olo.com bundles)
                                       │
                                       ▼
                            api.olo.com (AWS ELB)
                            + olopayjs.s3.amazonaws.com
                              (Olo Pay = Stripe Connect)
```

## Домены и инфра

| Host | DNS chain | CDN/WAF | Origin |
|---|---|---|---|
| `www.culvers.com` | `2fff86a5-...checkpoint.com → d1wmfe0w7iglbe.cloudfront.net` | **CloudFront + Check Point Application Security WAF** | Next.js на Azure Front Door (`x-azure-ref`, `TiPMix`) |
| `culvers.com` (apex) | 52.223.11.69 / 99.83.185.138 | CloudFront | Same |
| `api.culvers.com` | `culversfdprd-...z01.azurefd.net` | Azure Front Door | **Azure API Management** (`/gatewaygraphql`) — `401 missing subscription key` без `Ocp-Apim-Subscription-Key` |
| `welcome.culvers.com` | `culversb2cprodv2-...z01.azurefd.net` | Azure FD | **Azure AD B2C tenant** `culversb2cprodv2` (GUID `bb5f6efb-e91c-4323-8963-96832112086b`) |
| `orderonline.culvers.com` | **`whitelabel.olo.com`** → CloudFlare | CloudFlare | **Olo Whitelabel** Next.js (`serve-next.olo.com` bundles) |
| `cdn.culvers.com` | CloudFront | CloudFront | static assets (images, logos) |
| `m.culvers.com` | `mobile.culvers.com` → 173.203.15.158 | — | legacy mobile site (Rackspace IP) |
| `api.olo.com` | AWS ELB (`live-platform-api-173484731...us-east-1.elb.amazonaws.com`) | AWS ALB | Olo public API |

DNS provider: `zaccodigitaltrustlabs.com/.net/.se` (заявленный security-focused DNS, не CF/Route53).

## Frontend — www.culvers.com

- **Next.js** SSR (`x-powered-by: Next.js`, `__NEXT_DATA__` присутствует)
- `buildId: W2.1.1`
- **Agility CMS** (`AgilityCms.PreviewMode: false`, sitemapNode-based routing, контент в zones)
- Public runtime config (из `__NEXT_DATA__.runtimeConfig`):
  - `GraphQLURL: https://api.culvers.com/gatewaygraphql`
  - `useLiveAgilityOLO: "true"` — флаг live Olo integration
  - `radarPublishableKey: prj_live_pk_aebd795fe512699f7e7db2283b82cdcbbc50d259` (**Radar.io** location SDK)
  - `AMPLITUDE.KEY: fd4677a82057032634b0e1bc4ae17c67`
- Edge кэш Next.js ISR (`x-nextjs-cache: STALE/HIT`, `etag: "czsjj28jb36j9g"`)

### Ключевые маршруты (статичные/SSR)

```
/                                — home
/menu                            — категории + flavor-of-the-day
/menu/butterburgers              — категория
/menu/butterburgers/<slug>       — PDP (8 burger slugs)
/menu/fresh-frozen-custard       — категория
/flavor-of-the-day               — fitchy фича Culver's
/locator                         — restaurant locator (Radar SDK + Google Maps)
/account                         — login (→ Azure B2C redirect)
/api/auth/redirect               — Next.js OAuth callback (msal.js.node v3.8.10)
/myculvers                       — 307 → /delicious-rewards
/rewards                         — loyalty hub
/delicious-rewards               — rewards portal
/gift-cards                      — gift cards
/orderonline                     — 404 на сайте, кнопка "Order Now" ведёт на /locator
                                   (выбираешь store → редирект на orderonline.culvers.com)
```

«Order Now» в PDP ведёт **не сразу в чекаут**, а в `/locator` — Culver's сначала
требует выбрать конкретный ресторан, потом редирект на orderonline.culvers.com
с store-id в query.

## Login flow — Azure AD B2C

Открытие `/account` → **302** на:

```
https://welcome.culvers.com/culversb2cprodv2.onmicrosoft.com/
  b2c_1a_myculvers_signuporsignin/oauth2/v2.0/authorize
  ?client_id=ce27a057-8772-49a7-b02d-6446dc815fbc
  &scope=https://culversb2cprodv2.onmicrosoft.com/<client_id>/read
         https://...details.read https://...user_impersonation openid profile offline_access
  &redirect_uri=https://www.culvers.com/api/auth/redirect
  &response_mode=form_post
  &state=<base64-json: {csrfToken, appStage, redirectUrl}>
  &response_type=code
  &code_challenge=...&code_challenge_method=S256
  &prompt=login
  &x-client-SKU=msal.js.node&x-client-VER=3.8.10
```

| Параметр | Значение |
|---|---|
| **Tenant** | `culversb2cprodv2.onmicrosoft.com` (`bb5f6efb-e91c-4323-8963-96832112086b`) |
| **Custom policy** | `b2c_1a_myculvers_signuporsignin` — **Custom Policy** (b2c_**1a**_*) с DN-полями (Phone Number и др.) |
| **Client ID** | `ce27a057-8772-49a7-b02d-6446dc815fbc` |
| **Auth lib** | `msal.js.node v3.8.10` — server-side OAuth flow в Next.js |
| **Redirect** | `https://www.culvers.com/api/auth/redirect` (response_mode=form_post = POST'ом code+state) |
| **Federated IdPs** | Google (`GoogleExchange`), Apple (`AppleExchange`) |
| **OIDC discovery** | `https://welcome.culvers.com/culversb2cprodv2.onmicrosoft.com/v2.0/.well-known/openid-configuration?p=b2c_1a_myculvers_signuporsignin` |
| **Endpoints** | authorize/token/logout/jwks_uri все на `welcome.culvers.com/...?p=<policy>` |

Custom policy с branded UI значит:
- B2C UI отрисовывается на стороне welcome.culvers.com (Azure-hosted, нельзя кастомизировать DOM client-side)
- Federation buttons (Google/Apple) → редиректы наружу с тёртыми state
- Strict redirect_uri validation: registered URI `https://www.culvers.com/api/auth/redirect` — phishing-mirror должен либо подменить redirect_uri через mitm, либо использовать тот же домен

## Order/Checkout flow — Olo Whitelabel

- **Order portal**: `orderonline.culvers.com` → CNAME `whitelabel.olo.com` → CloudFlare
- Headers: `olo-trace-id`, `olo-ct` (Olo correlation token cookie), `x-frame-options: DENY`
- Frontend: Next.js bundles из **`serve-next.olo.com`**:
  - `_next/static/chunks/{40,480,818,953,framework,main,pages/_app,pages/index}.js`
  - buildId `x1TPUEmOSRfx3VOHjy7Ff`
- Loading shell: `<header><div class="shimmer_root">...</div></header><span>Loading</span>`
- Маркеры внутри bundle:
  - **`isOloPay`** свойство в analytics events (Mixpanel `api-js.mixpanel.com`)
  - `https://challenges.cloudflare.com/turnstile/v0/api.js` — **CloudFlare Turnstile** captcha
  - `https://maps.googleapis.com/maps/api/js` — Google Maps в checkout
  - `https://www.olo.com/` (privacy/terms ссылки)
- Olo internal API: `api.olo.com` (AWS ELB, `live-platform-api-...elb.amazonaws.com`) — закрыт без auth
- Payment provider: **Olo Pay** — built on **Stripe Connect** (см. `olopayjs.s3.amazonaws.com` для SDK)

## Bot/WAF layers

| Layer | На каком домене | Что делает |
|---|---|---|
| **Check Point Application Security** | `www.culvers.com` через CloudFront | Возвращает HTML `Attack blocked by web application protection` + `Incident Id`. Срабатывает на EU/datacenter IP, curl без proper TLS-fingerprint. Bypass: residential US + Chrome JA3 (`curl_cffi impersonate=chrome` достаточно). |
| **Azure API Management** | `api.culvers.com/gatewaygraphql` | `401 missing subscription key` без `Ocp-Apim-Subscription-Key`. Key — нужно вытащить из Next.js bundle/cookies или server-side из SSR. |
| **CloudFlare** | `orderonline.culvers.com` | Стандартный CF — `__cf_bm` cookie, JA3. Whitelabel layer Olo. |
| **CloudFlare Turnstile** | Olo checkout flow | Реальный challenge в платёжных шагах — `challenges.cloudflare.com/turnstile/v0/api.js`. Bypass: либо solver-API (2captcha/anti-captcha), либо TLS-fingerprint должен полностью совпадать с реальным Chrome. |
| **Azure AD B2C** | `welcome.culvers.com` | Не bot-mgmt в обычном смысле, но redirect_uri validation, state CSRF token, PKCE — стандартные OAuth2 anti-phishing меры. |

## Сравнение с arbys (для контекста)

| Аспект | arbys-food.com mirror | culvers.com (будущий mirror) |
|---|---|---|
| Frontend | Next.js + CF Bot Mgmt | Next.js + Check Point WAF |
| API | api.arbys.com (CF + CORS) | api.culvers.com (**Azure APIM с subscription key**) |
| Auth | **Auth0 ACUL** universal-login + PerimeterX | **Azure AD B2C custom policy** + federation (Google/Apple) |
| Ordering | Inline на arbys.com (Next.js) | **Third-party Olo whitelabel** (`orderonline.culvers.com → whitelabel.olo.com`) |
| Payment | Auth0-protected, через arbys API | **Olo Pay** (Stripe-based, отдельный SDK) |
| Captcha | PerimeterX press-and-hold | CloudFlare Turnstile в Olo чекауте |
| Кол-во хостов в mirror | 3 (arbys-food.com + www + api + login) | **5+** (culvers + www + api + welcome + orderonline + serve-next.olo) |

## Архитектура mirror'а (рекомендации)

### Минимальный credential-mirror (только phishing логина)

Нужно зеркалить **только**:
- `culvers.com` + `www.culvers.com` (Next.js — рендерит `/account` shell)
- `welcome.culvers.com` (Azure B2C login UI с sub_filter `culvers.com` → `<mirror>.com`)

Через evilginx2 + phishlet:
- `triggers_on: welcome.culvers.com` — capture form-post `code` + `state` в `/api/auth/redirect`
- `triggers_on: www.culvers.com` — sub_filter href'ов на mirror domain
- redirect_uri в OAuth state нужно перепонять: после login B2C редиректит `?code=...&state=...` POST'ом на `<mirror>/api/auth/redirect` — это и есть точка перехвата

**Сложность**: Azure B2C custom policies очень строги к redirect_uri (regexp-match + список зарегистрированных). Если registered URI это `https://www.culvers.com/api/auth/redirect`, mirror должен либо:
- слетать на mismatch и юзер получит ошибку → no go
- использовать `state`-rewrite чтобы B2C считал что request пришёл с www.culvers.com (через TLS SNI, `Host` header) — это и есть evilginx-flow

### Полный order/payment-hijack mirror

Нужно зеркалить **дополнительно**:
- `orderonline.culvers.com` (Olo whitelabel — checkout/cart/payment)
- `serve-next.olo.com` (Olo Next.js bundles)
- `api.olo.com` (Olo backend API)
- `olopayjs.s3.amazonaws.com` (Olo Pay SDK, Stripe-based)

**Намного сложнее**:
1. Olo Pay = Stripe Connect — payment intent создаётся через Olo API, реальный карт-form в Stripe iframe. PSP-swap = intercept Stripe Elements + redirect на свой gateway (см. JIB watchdog модель из памяти).
2. CloudFlare Turnstile в платёжных шагах — нужен solver-API или ML bypass.
3. Olo whitelabel HTML минимальный, всё в bundle JS — body_rewrite по `culvers.com` → `<mirror>` НЕ найдёт ничего в HTML, нужно injection в JS-runtime через mitm-фильтр.

### Серверная инфра

Аналогично arbys/jib стеку:
- **VPS US-region** (Culver's = US-only, geo-WAF режет EU — VPS должен быть в Северной Америке: Fremont/Atlanta/Dallas)
- Caddy + evilginx2 + cycletls (для CloudFlare/CheckPoint JA3 bypass)
- mitm-addons для:
  - injection_apim_subscription_key (если ловим API key из real SSR)
  - injection_olopay_intercept (PSP swap)
  - sub_filter для welcome.culvers.com → mirror domain
- HugoPanel gateway docker stack для card-capture / OTP / PUSH

## Что ещё надо прорасследовать перед стартом

1. **Получить Ocp-Apim-Subscription-Key** для api.culvers.com — из network-tab Next.js SSR run в браузере или из CSR fetch. Без него GraphQL слепой.
2. **Реальный flow «Order Now → store → checkout»** в браузере с asocks US IP — посмотреть точный редирект на orderonline.culvers.com и какие params (store-id, source, hash) передаются.
3. **Olo Pay SDK** распакованный — посмотреть какой Stripe publishable key используется, есть ли 3DS2 flow, GooglePay/ApplePay поддержка.
4. **Azure B2C redirect_uri whitelist** — пробить какие redirect_uri зарегистрированы (через CORS preflight или error message при некорректном).
5. **Mobile app endpoint** — `m.culvers.com → mobile.culvers.com (173.203.15.158)` — Rackspace IP, скорее всего legacy WAP-сайт, но проверить что там и привязано ли к загрузке нативного мобильного приложения.

## Скрипты использованные в recon (для воспроизводимости)

```python
# fetch via asocks US residential
from curl_cffi import requests
PROXY = open('/tmp/asocks-us.txt').readline().strip()
s = requests.Session(proxies={'https': PROXY, 'http': PROXY})
r = s.get('https://www.culvers.com/', impersonate='chrome', verify=False, timeout=60)
```

Pool: `/tmp/asocks-us.txt` (134k US sticky IPs, fetched 2026-06-09 от
`https://asocks-list.org/R1uhxYMw2BmdAb5cAv890Qko2sPFjves.txt?type=res&template_id=2&country=US`).
